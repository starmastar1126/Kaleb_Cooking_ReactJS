import React from 'react'
const Header = () => (
    <div className="Header">
        <div className="HeaderC">

                   <div className="logo1" > 
                        LOGO
                    </div>
                    <div className="bottoms1">
                        <div className="actbut1">
                            REGISTER
                        </div>
                        <div  className="actbut1">
                            LOG IN
                        </div>
                        <div  className="actbut">
                            <input type="text" className="searchi" placeholder="Search"></input>                    
                        </div>
                 

            </div>

        </div>
    </div>
)

export default Header;