from pymongo import MongoClient

client = MongoClient('mongodb+srv://atlasadmin:UK3o667%Zz4m@cluster0-ykwvb.mongodb.net')